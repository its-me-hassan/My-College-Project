# SkillSwap

SkillSwap is a student-to-student skill exchange website built with Python Flask, SQLite, HTML, and CSS.

## Features

- Student registration and login using registration number
- Password hashing
- Student dashboard
- Add skills to teach and skills to learn
- Search students by name, department, or skill
- Send skill exchange requests
- Accept or reject received requests
- SQLite database created automatically

## Requirements

- Python 3.9 or newer
- pip

## Run locally

1. Clone the repository:

   ```bash
   git clone YOUR_REPOSITORY_URL
   cd SkillSwap
   ```

2. Create and activate a virtual environment:

   Windows:

   ```bash
   python -m venv .venv
   .venv\\Scripts\\activate
   ```

   macOS or Linux:

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Set a secret key before running the application.

   Windows PowerShell:

   ```powershell
   $env:SECRET_KEY = "replace-with-a-long-random-secret"
   ```

   macOS or Linux:

   ```bash
   export SECRET_KEY="replace-with-a-long-random-secret"
   ```

5. Start the application:

   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

The SQLite database file is generated automatically and is excluded from Git by `.gitignore`.

## GitHub upload

```bash
git init
git add .
git commit -m "Add SkillSwap student skill exchange website"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

## Notes

This is an academic project starter. Before deploying it publicly, add CSRF protection, configure HTTPS, use a production WSGI server, and review authentication and privacy requirements. Never commit real student data, database files, passwords, or secret keys.
