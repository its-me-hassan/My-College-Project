document.addEventListener("DOMContentLoaded", () => {
    const alerts = document.querySelectorAll(".flash");
    alerts.forEach((alert) => {
        window.setTimeout(() => {
            alert.style.opacity = "0";
            alert.style.transition = "opacity 0.4s ease";
            window.setTimeout(() => alert.remove(), 450);
        }, 4500);
    });
});
